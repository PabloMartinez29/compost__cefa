ACTA DE REUNIÓN #17
========================================

INFORMACIÓN DEL ACTA:
- Número: 17
- Comité/Reunión: reunion final del proceso
- Ciudad: campoalegre
- Fecha: 23/09/0025
- Horario: 2025-11-21 14:00:00 - 2025-11-21 15:00:00
- Archivos adjuntos en BD: 3
- Archivos incluidos en ZIP: 3

ARCHIVOS INCLUIDOS:
==================
1. acta_17_informacion.html - Información completa en formato HTML
2. acta_17_datos.json - Datos estructurados en formato JSON
3. archivos_adjuntos/ - Carpeta con todos los documentos adjuntos (3 archivos)
4. README.txt - Este archivo con instrucciones

INSTRUCCIONES:
=============
- Para ver la información completa, abra el archivo HTML en su navegador
- Los datos JSON pueden ser importados en otros sistemas
- Los archivos adjuntos están organizados en la carpeta 'archivos_adjuntos'
- Este archivo fue generado automáticamente por el Sistema ComiSoftt

NOTA: Si la carpeta 'archivos_adjuntos' está vacía, significa que los archivos
originales no se encontraron en el servidor o no se guardaron correctamente.

Fecha de exportación: 21/11/2025 20:02:53
Sistema: ComiSoftt - Gestión de Actas de Reunión